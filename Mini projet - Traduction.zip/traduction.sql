-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 13 fév. 2022 à 11:22
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `traduction`
--

-- --------------------------------------------------------

--
-- Structure de la table `mots`
--

DROP TABLE IF EXISTS `mots`;
CREATE TABLE IF NOT EXISTS `mots` (
  `motsFrancais` varchar(20) NOT NULL,
  `motsAnglais` varchar(20) NOT NULL,
  `theme` varchar(20) NOT NULL,
  PRIMARY KEY (`motsFrancais`),
  KEY `theme` (`theme`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `mots`
--

INSERT INTO `mots` (`motsFrancais`, `motsAnglais`, `theme`) VALUES
('Chambre', 'bedroom', 'maison'),
('Chemise', 'shirt', 'vetements'),
('Crème', 'cream', 'alimentation'),
('Cuisine', 'kitchen', 'maison'),
('Fruit', 'fruit', 'alimentation'),
('Garage', 'garage', 'maison'),
('Légume', 'vegetable', 'alimentation'),
('Maison', 'house', 'maison'),
('Oignon', 'onion', 'alimentation'),
('Pantalon', 'pants', 'vetements'),
('Pull', 'swearter', 'vetements'),
('Raisin', 'grape', 'alimentation'),
('Robe', 'dress', 'vetements'),
('Salle de bain', 'bathroom', 'maison'),
('Tomate', 'tomato', 'alimentation'),
('Vêtement', 'clothe', 'vetements');

-- --------------------------------------------------------

--
-- Structure de la table `themes`
--

DROP TABLE IF EXISTS `themes`;
CREATE TABLE IF NOT EXISTS `themes` (
  `theme` varchar(20) NOT NULL,
  PRIMARY KEY (`theme`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `themes`
--

INSERT INTO `themes` (`theme`) VALUES
('alimentation'),
('maison'),
('vetements');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `mots`
--
ALTER TABLE `mots`
  ADD CONSTRAINT `contrainte` FOREIGN KEY (`theme`) REFERENCES `themes` (`theme`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
